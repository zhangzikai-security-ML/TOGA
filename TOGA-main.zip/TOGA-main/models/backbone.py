# import torch.nn as nn
# import torch
#
# def conv3x3(in_planes, out_planes, stride=1, groups=1, dilation=1):
#     """3x3 convolution with padding"""
#     return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,
#                      padding=dilation, groups=groups, bias=False, dilation=dilation)
#
#
# def conv1x1(in_planes, out_planes, stride=1):
#     """1x1 convolution"""
#     return nn.Conv2d(in_planes, out_planes, kernel_size=1, stride=stride, bias=False)
#
# class BasicBlock(nn.Module):
#     expansion = 1
#
#     def __init__(self, inplanes, planes, stride=1, downsample=None, groups=1,
#                  base_width=64, dilation=1, norm_layer=None):
#         super(BasicBlock, self).__init__()
#         if norm_layer is None:
#             norm_layer = nn.BatchNorm2d
#         if groups != 1 or base_width != 64:
#             raise ValueError('BasicBlock only supports groups=1 and base_width=64')
#         if dilation > 1:
#             raise NotImplementedError("Dilation > 1 not supported in BasicBlock")
#         # Both self.conv1 and self.downsample layers downsample the input when stride != 1
#         self.conv1 = conv3x3(inplanes, planes, stride)
#         self.bn1 = norm_layer(planes)
#         self.relu = nn.ReLU(inplace=True)
#         self.conv2 = conv3x3(planes, planes)
#         self.bn2 = norm_layer(planes)
#         self.downsample = downsample
#         self.stride = stride
#
#     def forward(self, x):
#         identity = x
#
#         out = self.conv1(x)
#         out = self.bn1(out)
#         out = self.relu(out)
#
#         out = self.conv2(out)
#         out = self.bn2(out)
#
#         if self.downsample is not None:
#             identity = self.downsample(x)
#
#         out += identity
#         out = self.relu(out)
#
#         return out
#
#
# class ResNet(nn.Module):
#
#     def __init__(self, block, layers, modality, num_classes=1000, pool='avgpool', zero_init_residual=False,
#                  groups=1, width_per_group=64, replace_stride_with_dilation=None,
#                  norm_layer=None):
#         super(ResNet, self).__init__()
#         self.modality = modality
#         self.pool = pool
#         if norm_layer is None:
#             norm_layer = nn.BatchNorm2d
#         self._norm_layer = norm_layer
#
#         self.inplanes = 64
#         self.dilation = 1
#         if replace_stride_with_dilation is None:
#             # each element in the tuple indicates if we should replace
#             # the 2x2 stride with a dilated convolution instead
#             replace_stride_with_dilation = [False, False, False]
#         if len(replace_stride_with_dilation) != 3:
#             raise ValueError("replace_stride_with_dilation should be None "
#                              "or a 3-element tuple, got {}".format(replace_stride_with_dilation))
#         self.groups = groups
#         self.base_width = width_per_group
#         if modality == 'audio':
#             self.conv1 = nn.Conv2d(1, self.inplanes, kernel_size=7, stride=2, padding=3,
#                                    bias=False)
#         elif modality == 'visual':
#             self.conv1 = nn.Conv2d(3, self.inplanes, kernel_size=7, stride=2, padding=3,
#                                    bias=False)
#         elif modality == 'flow':
#             self.conv1 = nn.Conv2d(2, self.inplanes, kernel_size=7, stride=2, padding=3,
#                                    bias=False)
#         elif modality == 'rgb':
#             self.conv1 = nn.Conv2d(3, self.inplanes, kernel_size=7, stride=2, padding=3,
#                                    bias=False)
#         else:
#             raise NotImplementedError('Incorrect modality, should be audio or visual but got {}'.format(modality))
#         self.bn1 = norm_layer(self.inplanes)
#         self.relu = nn.ReLU(inplace=True)
#         self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
#         self.layer1 = self._make_layer(block, 64, layers[0])
#         self.layer2 = self._make_layer(block, 128, layers[1], stride=2,
#                                        dilate=replace_stride_with_dilation[0])
#         self.layer3 = self._make_layer(block, 256, layers[2], stride=2,
#                                        dilate=replace_stride_with_dilation[1])
#         self.layer4 = self._make_layer(block, 512, layers[3], stride=2,
#                                        dilate=replace_stride_with_dilation[2])
#         # if self.pool == 'avgpool':
#         #     self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
#         #
#         #     self.fc = nn.Linear(512 * block.expansion, num_classes)  # 8192
#
#         for m in self.modules():
#             if isinstance(m, nn.Conv2d):
#                 nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
#             elif isinstance(m, (nn.BatchNorm2d, nn.GroupNorm)):
#                 nn.init.normal_(m.weight, mean=1, std=0.02)
#                 nn.init.constant_(m.bias, 0)
#
#         # Zero-initialize the last BN in each residual branch,
#         # so that the residual branch starts with zeros, and each residual block behaves like an identity.
#         # This improves the model by 0.2~0.3% according to https://arxiv.org/abs/1706.02677
#         if zero_init_residual:
#             for m in self.modules():
#                 if isinstance(m, Bottleneck):
#                     nn.init.constant_(m.bn3.weight, 0)
#                 elif isinstance(m, BasicBlock):
#                     nn.init.constant_(m.bn2.weight, 0)
#
#     def _make_layer(self, block, planes, blocks, stride=1, dilate=False):
#         norm_layer = self._norm_layer
#         downsample = None
#         previous_dilation = self.dilation
#         if dilate:
#             self.dilation *= stride
#             stride = 1
#         if stride != 1 or self.inplanes != planes * block.expansion:
#             downsample = nn.Sequential(
#                 conv1x1(self.inplanes, planes * block.expansion, stride),
#                 norm_layer(planes * block.expansion),
#             )
#
#         layers = []
#         layers.append(block(self.inplanes, planes, stride, downsample, self.groups,
#                             self.base_width, previous_dilation, norm_layer))
#         self.inplanes = planes * block.expansion
#         for _ in range(1, blocks):
#             layers.append(block(self.inplanes, planes, groups=self.groups,
#                                 base_width=self.base_width, dilation=self.dilation,
#                                 norm_layer=norm_layer))
#
#         return nn.Sequential(*layers)
#
#     def forward(self, x):
#
#         if self.modality == 'visual':
#             (B, C, T, H, W) = x.size()
#             x = x.permute(0, 2, 1, 3, 4).contiguous()
#             x = x.view(B * T, C, H, W)
#         if self.modality == 'flow':
#             (B, T, C, H, W) = x.size()
#             x = x.contiguous()
#             x = x.view(B * T, C, H, W)
#         x = self.conv1(x)
#         x = self.bn1(x)
#         x = self.relu(x)
#         x = self.maxpool(x)
#
#         x = self.layer1(x)
#         x = self.layer2(x)
#         x = self.layer3(x)
#         x = self.layer4(x)
#         out = x
#
#         return out
#
#
# class Bottleneck(nn.Module):
#     expansion = 4
#
#     def __init__(self, inplanes, planes, stride=1, downsample=None, groups=1,
#                  base_width=64, dilation=1, norm_layer=None):
#         super(Bottleneck, self).__init__()
#         if norm_layer is None:
#             norm_layer = nn.BatchNorm2d
#         width = int(planes * (base_width / 64.)) * groups
#         # Both self.conv2 and self.downsample layers downsample the input when stride != 1
#         self.conv1 = conv1x1(inplanes, width)
#         self.bn1 = norm_layer(width)
#         self.conv2 = conv3x3(width, width, stride, groups, dilation)
#         self.bn2 = norm_layer(width)
#         self.conv3 = conv1x1(width, planes * self.expansion)
#         self.bn3 = norm_layer(planes * self.expansion)
#         self.relu = nn.ReLU(inplace=True)
#         self.downsample = downsample
#         self.stride = stride
#
#     def forward(self, x):
#         identity = x
#
#         out = self.conv1(x)
#         out = self.bn1(out)
#         out = self.relu(out)
#
#         out = self.conv2(out)
#         out = self.bn2(out)
#         out = self.relu(out)
#
#         out = self.conv3(out)
#         out = self.bn3(out)
#
#         if self.downsample is not None:
#             identity = self.downsample(x)
#
#         out += identity
#         out = self.relu(out)
#
#         return out
#
# def cross_modality_pretrain(conv1_weight, channel):
#     # transform the original 3 channel weight to "channel" channel
#     S=0
#     for i in range(3):
#         S += conv1_weight[:,i,:,:]
#     avg = S/3.
#     new_conv1_weight = torch.FloatTensor(64,channel,7,7)
#
#     for i in range(channel):
#         new_conv1_weight[:,i,:,:] = avg.data
#     return new_conv1_weight
#
# def load_pretrain(model,modality):
#     checkpoint = torch.load('pretrained/resnet18-f37072fd.pth', map_location='cpu')
#     checkpoint.pop('fc.weight')
#     checkpoint.pop('fc.bias')
#     if modality == "audio":
#         checkpoint['conv1.weight'] = cross_modality_pretrain(checkpoint['conv1.weight'], 1)
#     elif modality == "flow":
#         checkpoint['conv1.weight'] = cross_modality_pretrain(checkpoint['conv1.weight'], 2)
#     model.load_state_dict(checkpoint)
#     return model
# def _resnet(arch, block, layers, modality, pretrain, **kwargs):
#     model = ResNet(block, layers, modality, **kwargs)
#     if pretrain:
#         model = load_pretrain(model,modality)
#     return model
#
#
# def resnet18(modality, pretrain=False, **kwargs):
#     return _resnet('resnet18', BasicBlock, [2, 2, 2, 2], modality, pretrain,
#                    **kwargs)
import torch
import torch.nn as nn
import torch.nn.utils as utils

class LSTMEncoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, dropout=0.5):
        """
        Args:
            input_dim (int): 输入特征维度 (Text: 768, Audio: 5, Visual: 20)
            hidden_dim (int): LSTM 隐藏层维度 (比如 128)
            output_dim (int): 最终输出的特征维度 (比如 128，用于融合)
            dropout (float): Dropout 概率
        """
        super(LSTMEncoder, self).__init__()
        # LSTM 层：处理时序信息
        # batch_first=True 意味着输入形状是 (Batch, Seq_Len, Feature)
        self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True, bidirectional=False)

        # 线性层：将 LSTM 的最终状态映射到统一的 output_dim
        self.fc = nn.Sequential(
            # nn.Linear(hidden_dim, output_dim),
            utils.spectral_norm(nn.Linear(hidden_dim, output_dim)), #引入谱归一化，可以限制参数矩阵的缩放倍数，让模型在接受大梯度时依然保持平滑
            nn.BatchNorm1d(output_dim),  # 加个 BN 稳定训练
            nn.ReLU(),
            nn.Dropout(0.5)
        )

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): [Batch_Size, Seq_Len, Input_Dim]
        Returns:
            out (torch.Tensor): [Batch_Size, Output_Dim]
        """
        # LSTM 输出: output, (h_n, c_n)
        # 我们只需要最后时刻的隐藏状态 h_n
        self.lstm.flatten_parameters()  # 优化内存，防止警告
        _, (h_n, _) = self.lstm(x)

        # h_n shape: [num_layers * num_directions, Batch, Hidden_Dim]
        # 我们只用了单向单层，所以取 h_n[0] 或者 squeeze
        feat = h_n[-1]  # [Batch, Hidden_Dim]

        # 通过全连接层映射
        out = self.fc(feat)
        return out


# 定义工厂函数，方便外部调用 (保持接口风格)
def mosi_encoder(input_dim, hidden_dim=128, output_dim=128):
    return LSTMEncoder(input_dim, hidden_dim, output_dim)